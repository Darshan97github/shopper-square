import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    productList: {
        "status":"200",
        "message":"ok",
        "featuredData":[
            {
                "catogery":'Home',
                "title":"Best Deal on this Holiday",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img2.jpg",
                "price":"200"
            },
            {
                "catogery":'Accessories',
                "title":"TV & Audio stream etc...",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img3.jpg",
                "price":"240"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img1.jpg",
                "price":"2000"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream etc...",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img2.jpg",
                "price":"1040"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img1.jpg",
                "price":"999"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img3.jpg",
                "price":"1040"
            }
        ],
        "OnsaleData":[
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img1.jpg",
                "price":"200"
            },
            {
                "catogery":'Accessories',
                "title":"TV & Audio stream etc...",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img2.jpg",
                "price":"240"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream etc...",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img3.jpg",
                "price":"2000"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img2.jpg",
                "price":"1040"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img1.jpg",
                "price":"999"
            },
            {
                "catogery":'Tech',
                "title":"Wireless Audio stream ",
                "img":"https://transvelo.github.io/electro-html/2.0/assets/img/212X200/img2.jpg",
                "price":"1040"
            }
        ]
    }
    
}

const productSlice = createSlice({
    name: 'product',
    initialState,
    reducers: {
      noReducer: (state, action) => {}
    }
});

export const {noReducer} = productSlice.actions

export const getProductData = state => state.product.productList

export default productSlice.reducer