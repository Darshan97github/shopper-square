import React from "react";
import { Container } from "react-bootstrap";

function Ads() {
  return (
    <>
      <Container className="mt-3 ">
        <img
          width="100%"
          src="https://www.webfx.com/blog/wp-content/uploads/2019/10/banner-ad-example-online.png"
          alt=""
        />
      </Container>
    </>
  );
}

export default Ads;
