const cardData = [
    {
      img:'https://transvelo.github.io/electro-html/2.0/assets/img/190X150/img1.png',
      text1:'CATCH BIG ',
      strongText:'DEAL',
      text2:' ON CAMERA'
    },
    {
      img:'https://transvelo.github.io/electro-html/2.0/assets/img/190X150/img2.jpg',
      text1:'OFFER ON',
      strongText:'FASHION',
      text2:'CLOTHING'
    },
    {
      img:'https://transvelo.github.io/electro-html/2.0/assets/img/190X150/img3.jpg',
      text1:'DEAL',
      strongText:'OF',
      text2:'THE DAY'
    }
  ]


  export default cardData;