import React from 'react'

function FavoriteCard() {
    return (
        <div>
            <h3>Favorite card</h3>
        </div>
    )
}

export default FavoriteCard
