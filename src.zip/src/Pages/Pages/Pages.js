import React from 'react'

function Pages() {
    return (
        <div>
            <h3>Pages</h3>
        </div>
    )
}

export default Pages
